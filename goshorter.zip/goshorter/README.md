# GoShorter

A URL shortener written in Golang.

## Installation

### Using Podman
```bash
podman compose build && podman compose up
```

### Using Docker
```bash
docker-compose build && docker-compose up
```

## Accessing

The application should be available at `http://localhost:8888`
