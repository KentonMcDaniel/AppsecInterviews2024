package main

import (
	"goshorter/pkg/goshorter"
)

func main() {
	dbCfg := goshorter.DBConfig{
		Host:     "db",
		Port:     5432,
		User:     "goshorter_user",
		Password: "password",
		DBName:   "goshorter_db",
	}

	goshorter.StartServer(dbCfg)
}
