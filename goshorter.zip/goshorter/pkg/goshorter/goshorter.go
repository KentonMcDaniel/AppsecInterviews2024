package goshorter

import (
	"crypto/md5"
	"encoding/base32"
	"fmt"
	"log"
	"net/http"
)

var db *DB

// generateSlug creates a URL-friendly slug from the given URL.
func generateSlug(url string) string {
	// Create a MD5 hash of the URL.
	hasher := md5.New()
	hasher.Write([]byte(url))
	hash := hasher.Sum(nil)

	// Encode the hash using base32 to get a URL-friendly string.
	encoded := base32.StdEncoding.EncodeToString(hash)

	// Truncate to 4 characters for simplicity
	slug := fmt.Sprintf("%s", encoded[:4])

	return slug
}

// StartServer starts the HTTP server and handles incoming requests.
func StartServer(dbcfg DBConfig) {
	db, _ = NewDB(dbcfg)
	defer db.Close()

	SetupRoutes()

	// Start the server
	log.Println("Starting server on :8888")
	if err := http.ListenAndServe(":8888", nil); err != nil {
		log.Fatal(err)
	}
}
