package goshorter

import (
	"context"
	"database/sql"
	"fmt"
	"math"
	"time"

	_ "github.com/lib/pq"
)

// DBConfig holds the configuration for the database connection.
type DBConfig struct {
	Host     string
	Port     int
	User     string
	Password string
	DBName   string
}

type DB struct {
	*sql.DB
}

type URLMapping struct {
	URL      string
	Slug     string
	Accesses int
}

// DatabaseStats holds statistics about the URL mappings in the database.
type DatabaseStats struct {
	TotalURLs       int
	TotalAccesses   int
	AverageAccesses float64
}

// NewDB creates a new database connection and ensures the table exists.
func NewDB(cfg DBConfig) (*DB, error) {
	if cfg.Host == "" || cfg.User == "" || cfg.Password == "" || cfg.DBName == "" {
		return nil, fmt.Errorf("missing required field in DBConfig")
	}

	psqlInfo := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable",
		cfg.Host, cfg.Port, cfg.User, cfg.Password, cfg.DBName)

	db, err := sql.Open("postgres", psqlInfo)
	if err != nil {
		return nil, fmt.Errorf("Error connecting to the database: %w", err)
	}

	err = db.Ping()
	if err != nil {
		return nil, fmt.Errorf("Error pinging the database: %w", err)
	}

	err = (&DB{db}).initTable() // Calls initTable on db
	if err != nil {
		return nil, fmt.Errorf("Error ensuring table exists: %w", err)
	}

	return &DB{db}, nil
}

func (d *DB) tableExists(table string) (bool, error) {
	var n int64
	err := d.QueryRow("select 1 from information_schema.tables where table_name = $1", table).Scan(&n)
	if err != nil {
		if err.Error() == sql.ErrNoRows.Error() {
			return false, nil
		}
		return false, err
	}

	return true, nil
}

// ensureTableExists creates the url_mappings table if it doesn't exist.
func (d *DB) initTable() error {

	if exists, err := d.tableExists("url_mappings"); err != nil || !exists {
		createTableSQL := `CREATE TABLE IF NOT EXISTS url_mappings (
			id SERIAL PRIMARY KEY,
			slug VARCHAR(255) UNIQUE NOT NULL,
			url TEXT UNIQUE NOT NULL,
			access_count INTEGER NOT NULL DEFAULT 0
		);`
		_, err := d.Exec(createTableSQL)
		if err != nil {
			return fmt.Errorf("Error ensuring url_mappings table exists: %s", err)
		}
		insertDefaultDataSQL := `INSERT INTO url_mappings (slug, url) VALUES ('default', 'https://example.com')`
		_, err = d.Exec(insertDefaultDataSQL)
		if err != nil {
			return fmt.Errorf("Error inserting default data: %s", err)
		}
	}
	return nil
}

// storeURLMapping stores a new URL mapping in the database.
func (d *DB) storeURLMapping(slug string, url string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	insertQuery := `INSERT INTO url_mappings (slug, url) VALUES ($1, $2) RETURNING slug`
	err := d.QueryRowContext(ctx, insertQuery, slug, url).Scan(&slug)
	if err != nil {
		return "", fmt.Errorf("Failed to insert URL mapping: %v", err)
	}

	return slug, nil
}

// getURLFromSlug retrieves the original URL from the database based on the slug.
func (d *DB) getURLFromSlug(slug string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var url string
	query := fmt.Sprintf("SELECT url FROM url_mappings WHERE slug = '%s'", slug)
	err := d.QueryRowContext(ctx, query).Scan(&url)
	if err != nil {
		return "", err
	}

	return url, nil
}

// incrementAccessCount increments the access count for the given slug.
func (d *DB) incrementAccessCount(slug string) error {
	_, err := d.Exec("UPDATE url_mappings SET access_count = access_count + 1 WHERE slug = $1", slug)
	if err != nil {
		return fmt.Errorf("failed to update access count: %v", err)
	}
	return nil
}

// getTopURLs retrieves the top 10 most accessed URLs from the database.
func (d *DB) getTopURLs() ([]URLMapping, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	query := `SELECT url, slug, access_count FROM url_mappings ORDER BY access_count DESC LIMIT 10`
	rows, err := d.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var mappings []URLMapping
	for rows.Next() {
		var mapping URLMapping
		if err := rows.Scan(&mapping.URL, &mapping.Slug, &mapping.Accesses); err != nil {
			return nil, err
		}
		mappings = append(mappings, mapping)
	}

	return mappings, nil
}

// updateURLMapping updates the URL for the given slug in the database.
func (d *DB) updateURLMapping(slug string, newURL string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	query := `UPDATE url_mappings SET url = $1 WHERE slug = $2`
	_, err := d.ExecContext(ctx, query, newURL, slug)
	return err
}

// deleteURLMapping deletes a URL mapping from the database based on the slug.
func (d *DB) deleteURLMapping(slug string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	query := `DELETE FROM url_mappings WHERE slug = $1`
	_, err := d.ExecContext(ctx, query, slug)
	return err
}

// getPaginatedURLMappings retrieves a paginated list of URL mappings from the database.
func (d *DB) getPaginatedURLMappings(page, limit int) ([]URLMapping, int, error) {
	offset := (page - 1) * limit

	query := `SELECT url, slug, access_count FROM url_mappings ORDER BY access_count DESC LIMIT $1 OFFSET $2`
	rows, err := d.Query(query, limit, offset)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var mappings []URLMapping
	for rows.Next() {
		var mapping URLMapping
		if err := rows.Scan(&mapping.URL, &mapping.Slug, &mapping.Accesses); err != nil {
			return nil, 0, err
		}
		mappings = append(mappings, mapping)
	}

	// Calculate total pages
	var totalCount int
	err = d.QueryRow("SELECT COUNT(*) FROM url_mappings").Scan(&totalCount)
	if err != nil {
		return nil, 0, err
	}
	totalPages := int(math.Ceil(float64(totalCount) / float64(limit)))

	return mappings, totalPages, nil
}

// getDatabaseStats calculates and returns statistics about the URL mappings.
func (d *DB) getDatabaseStats() (DatabaseStats, error) {
	stats := DatabaseStats{}

	// Calculate total number of URLs
	err := d.QueryRow("SELECT COUNT(*) FROM url_mappings").Scan(&stats.TotalURLs)
	if err != nil {
		return stats, fmt.Errorf("failed to calculate total URLs: %v", err)
	}

	// Calculate total accesses
	err = d.QueryRow("SELECT SUM(access_count) FROM url_mappings").Scan(&stats.TotalAccesses)
	if err != nil {
		return stats, fmt.Errorf("failed to calculate total accesses: %v", err)
	}

	// Calculate average accesses per URL
	if stats.TotalURLs > 0 {
		stats.AverageAccesses = float64(stats.TotalAccesses) / float64(stats.TotalURLs)
	}

	return stats, nil
}
