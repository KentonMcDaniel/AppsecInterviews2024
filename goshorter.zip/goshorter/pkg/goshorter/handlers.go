package goshorter

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"text/template"
)

func getProtoAndHost(r *http.Request) (string, string) {
	proto := "http"
	if r.TLS != nil {
		proto = "https"
	}
	host := r.Host
	if r.Host == "" {
		host = r.Header.Get("X-Forwarded-Host")
		if host == "" {
			host = r.Host
		}
	}
	return proto, host
}

// indexHandler handles the index page.
func indexHandler(w http.ResponseWriter, r *http.Request) {
	topURLs, err := db.getTopURLs()
	if err != nil {
		http.Error(w, "Failed to fetch top URLs", http.StatusInternalServerError)
		return
	}

	stats, err := db.getDatabaseStats()
	if err != nil {
		http.Error(w, "Failed to fetch database statistics", http.StatusInternalServerError)
		return
	}

	// Create a struct to hold both the top URLs and the stats
	data := struct {
		TopURLs []URLMapping
		Stats   DatabaseStats
	}{
		TopURLs: topURLs,
		Stats:   stats,
	}

	// Pass the data to the template
	tmpl := template.Must(template.ParseFiles("web/templates/index.html"))
	tmpl.Execute(w, data)
}

// editHandler handles the edit page.
func editHandler(w http.ResponseWriter, r *http.Request) {
	slug := r.URL.Path[len("/edit/"):]

	url, err := db.getURLFromSlug(slug)
	if err != nil {
		http.Error(w, "Slug not found", http.StatusNotFound)
		return
	}

	tmpl := template.Must(template.ParseFiles("web/templates/edit.html"))
	tmpl.Execute(w, map[string]string{"Slug": slug, "URL": url})
}

// updateHandler handles the update page.
func updateHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	slug := r.URL.Path[len("/update/"):]

	if err := r.ParseForm(); err != nil {
		http.Error(w, "Failed to parse form", http.StatusBadRequest)
		return
	}

	newURL := r.FormValue("url")
	if err := db.updateURLMapping(slug, newURL); err != nil {
		http.Error(w, "Failed to update URL mapping", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

// shortenHandler handles the shortening of a URL.
func shortenHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseMultipartForm(100000); err != nil {
		http.Error(w, "Failed to parse form", http.StatusBadRequest)
		return
	}

	url := r.FormValue("url")
	proto, host := getProtoAndHost(r)
	slug, err := db.storeURLMapping(generateSlug(url), url)
	if err != nil {
		http.Error(w, "Failed to store URL mapping", http.StatusInternalServerError)
		return
	}
	shortenedUrl := fmt.Sprintf("%s://%s/r/%s", proto, host, slug)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"shortenedUrl": shortenedUrl})
}

// redirectionHandler handles the redirection to the original URL.
func redirectionHandler(w http.ResponseWriter, r *http.Request) {
	slug := r.URL.Path[len("/r/"):]

	err := db.incrementAccessCount(slug)
	if err != nil {
		http.Error(w, "Failed to update access count", http.StatusInternalServerError)
		return
	}

	// Retrieve the original URL and redirect
	url, err := db.getURLFromSlug(slug)
	if err != nil {
		http.Error(w, "URL not found", http.StatusNotFound)
		return
	}

	http.Redirect(w, r, url, http.StatusFound)
}

// Helper functions
func add(a, b int) int {
	return a + b
}

func sub(a, b int) int {
	return a - b
}

// Modify the fullListHandler to register the helper functions with the template
func fullListHandler(w http.ResponseWriter, r *http.Request) {
	pageStr := r.URL.Query().Get("page")
	var page int
	var err error
	if pageStr == "" {
		page = 1
	} else {
		page, err = strconv.Atoi(pageStr)
		if err != nil || page < 1 {
			page = 1
		}
	}

	// Retrieve the paginated list of URL mappings
	urlMappings, totalPages, err := db.getPaginatedURLMappings(page, 10) // Assuming 10 items per page
	if err != nil {
		http.Error(w, "Failed to fetch URL mappings", http.StatusInternalServerError)
		return
	}

	// Calculate PagesBefore and PagesAfter
	var pagesBefore, pagesAfter []int
	for i := 1; i <= 5; i++ {
		if page-i > 0 {
			pagesBefore = append([]int{page - i}, pagesBefore...)
		}
		if page+i <= totalPages {
			pagesAfter = append(pagesAfter, page+i)
		}
	}

	data := struct {
		URLMappings []URLMapping
		CurrentPage int
		TotalPages  int
		PagesBefore []int
		PagesAfter  []int
	}{
		URLMappings: urlMappings,
		CurrentPage: page,
		TotalPages:  totalPages,
		PagesBefore: pagesBefore,
		PagesAfter:  pagesAfter,
	}

	funcMap := template.FuncMap{
		"add": add,
		"sub": sub,
	}

	tmpl, err := template.New("full_list.html").Funcs(funcMap).ParseFiles("web/templates/full_list.html")
	if err != nil {
		http.Error(w, "Failed to parse template", http.StatusInternalServerError)
		log.Println(err)
		return
	}

	err = tmpl.ExecuteTemplate(w, "full_list.html", data)
	if err != nil {
		http.Error(w, "Failed to execute template", http.StatusInternalServerError)
		log.Println(err)
		return
	}
}

// deleteHandler handles the deletion of a URL mapping.
func deleteHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	slug := r.URL.Path[len("/delete/"):]

	if err := db.deleteURLMapping(slug); err != nil {
		http.Error(w, "Failed to delete URL mapping", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/full-list?page=1", http.StatusSeeOther)
}

// Add the route in SetupRoutes function
func SetupRoutes() {
	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/shorten", shortenHandler)
	http.HandleFunc("/r/", redirectionHandler)
	http.HandleFunc("/edit/", editHandler)
	http.HandleFunc("/update/", updateHandler)
	http.HandleFunc("/full-list", fullListHandler)
	http.HandleFunc("/delete/", deleteHandler)
}
